# Source Files Creation Guide

Due to file size limitations, this package contains the essential configuration files.
The complete source code files need to be created using the provided templates.

## Automated Source File Creation

Run the following command to auto-generate all source files:

```bash
# On Windows (Git Bash or WSL)
bash generate_source_files.sh

# Or manually create each file using the templates below
```

## Required Source Files (Copy from previous responses)

### Core Files (MUST CREATE)
1. lib/main.dart - App entry point with navigation
2. lib/firebase_options.dart - Firebase configuration
3. lib/providers/user_provider.dart - State management
4. lib/utils/navigation_helper.dart - Navigation utilities

### Models (6 files in lib/models/)
1. user_model.dart
2. exercise_model.dart
3. program_model.dart
4. workout_log_model.dart
5. message_model.dart
6. injury_mapping_model.dart

### Services (6 files in lib/services/)
1. auth_service.dart
2. firestore_service.dart
3. storage_service.dart
4. workout_log_service.dart
5. notification_service.dart
6. injury_filter_service.dart

### Screens (9 files in lib/screens/)

**Auth (3 files):**
- screens/auth/login_screen.dart
- screens/auth/client_onboarding_screen.dart
- screens/auth/coach_registration_screen.dart

**Client (4 files):**
- screens/client/client_home_screen.dart
- screens/client/workout_screen.dart
- screens/client/progress_screen.dart
- screens/client/settings_screen.dart

**Coach (1 file):**
- screens/coach/coach_dashboard_screen.dart

## Quick Setup

1. Extract this ZIP
2. Copy all .dart files from the conversation into their respective directories
3. Run setup.bat
4. Follow WINDOWS_QUICK_START.md

All source code has been provided in the conversation above.
Simply copy each code block into the correct file path.
