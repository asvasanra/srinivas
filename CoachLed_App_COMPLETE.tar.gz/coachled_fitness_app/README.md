# CoachLed Fitness App

A Flutter + Firebase fitness coaching application for 40+ clients with rehab-aware training.

## 🚀 Quick Start (Windows)

### Prerequisites
1. Install Flutter SDK: https://docs.flutter.dev/get-started/install/windows
2. Install Android Studio: https://developer.android.com/studio
3. Install Git: https://git-scm.com/download/win
4. Create Firebase project: https://console.firebase.google.com

### Step 1: Setup Flutter
```bash
# Verify Flutter installation
flutter doctor

# If any issues, follow the instructions from flutter doctor
```

### Step 2: Install Dependencies
```bash
# Navigate to project directory
cd coachled_fitness_app

# Get Flutter packages
flutter pub get
```

### Step 3: Configure Firebase

**Option A: Automatic (Recommended)**
```bash
# Install FlutterFire CLI
dart pub global activate flutterfire_cli

# Configure Firebase
flutterfire configure

# Select your Firebase project
# Select Android platform (iOS requires macOS)
```

**Option B: Manual**
1. Go to Firebase Console
2. Create new project or select existing
3. Add Android app
4. Download `google-services.json`
5. Place in `android/app/` directory
6. Copy Firebase config values to `lib/firebase_options.dart`

### Step 4: Enable Firebase Services

**Firebase Console Setup:**
1. **Authentication**
   - Go to Authentication > Sign-in method
   - Enable "Phone" authentication
   - Add test phone: +1 555 000 0001, Code: 123456

2. **Firestore Database**
   - Go to Firestore Database
   - Click "Create database" (Production mode)
   - Copy rules from `firestore.rules` file
   - Paste in Firestore Rules tab

3. **Storage**
   - Go to Storage
   - Click "Get started" (Production mode)
   - Copy rules from `storage.rules` file
   - Paste in Storage Rules tab

4. **Seed Data**
   - Go to Firestore Database
   - Create collection: `injury_mappings`
   - Import data from `firestore_seed_data.json`
   - Create collection: `exercises`
   - Add sample exercise from `sample_exercise.json`

### Step 5: Run the App
```bash
# Connect Android device or start emulator
# List devices
flutter devices

# Run app
flutter run
```

## 📱 Testing the App

### Test Account Login
Use test phone number:
- Phone: +1 555 000 0001
- Code: 123456

### Test Flow
1. ✅ Login with phone OTP
2. ✅ Complete onboarding (4 steps)
3. ✅ View client home dashboard
4. ✅ (Need program) Start workout
5. ✅ View progress
6. ✅ Update settings
7. ✅ Sign out

### Create Test Program
To test workouts, create a program in Firestore:
1. Go to Firestore > programs collection
2. Add document with your user_id from users collection
3. Use fields from `sample_program.json`

## 🐛 Troubleshooting

**Issue: Firebase not initialized**
```bash
# Run FlutterFire configure again
flutterfire configure --force
```

**Issue: Gradle build failed**
```bash
cd android
./gradlew clean
cd ..
flutter clean
flutter pub get
flutter run
```

**Issue: Phone auth not working**
- Verify phone auth is enabled in Firebase Console
- Check SHA-1 fingerprint is added to Firebase project
- Use test phone numbers for development

**Issue: Dependencies error**
```bash
flutter pub upgrade
flutter pub get
```

## 📁 Project Structure

```
coachled_fitness_app/
├── lib/
│   ├── main.dart                      # App entry point
│   ├── firebase_options.dart          # Firebase config
│   ├── models/                        # Data models
│   ├── services/                      # Business logic
│   ├── screens/                       # UI screens
│   │   ├── auth/                      # Login, onboarding
│   │   ├── client/                    # Client screens
│   │   └── coach/                     # Coach screens
│   ├── providers/                     # State management
│   ├── utils/                         # Helpers
│   └── widgets/                       # Reusable widgets
├── android/                           # Android config
├── firestore.rules                    # Firestore security rules
├── storage.rules                      # Storage security rules
└── pubspec.yaml                       # Dependencies
```

## 🔧 Configuration Files

All configuration files are included:
- ✅ `pubspec.yaml` - All dependencies
- ✅ `firestore.rules` - Database security
- ✅ `storage.rules` - File storage security
- ✅ `firestore_seed_data.json` - Injury mappings
- ✅ `sample_exercise.json` - Test exercise
- ✅ `sample_program.json` - Test program

## 📚 Documentation

- `SETUP_GUIDE.md` - Detailed setup instructions
- `DEPLOYMENT.md` - Production deployment guide
- `API_DOCUMENTATION.md` - Firebase structure

## 🆘 Support

If you encounter issues:
1. Check `TROUBLESHOOTING.md`
2. Run `flutter doctor -v`
3. Check Firebase Console logs
4. Verify all rules are deployed

## 📄 License

Proprietary - All rights reserved
