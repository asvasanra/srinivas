# Windows Quick Start Guide

## Prerequisites (Install These First)

1. **Flutter SDK** 
   - Download: https://docs.flutter.dev/get-started/install/windows
   - Extract to C:\src\flutter
   - Add to PATH: C:\src\flutter\bin

2. **Android Studio**
   - Download: https://developer.android.com/studio
   - Install Android SDK
   - Install Android SDK Command-line Tools
   - Install Android SDK Build-Tools
   - Install Android Emulator

3. **Git for Windows**
   - Download: https://git-scm.com/download/win

4. **VS Code** (Optional but recommended)
   - Download: https://code.visualstudio.com/
   - Install Flutter extension
   - Install Dart extension

## Step-by-Step Setup

### 1. Verify Flutter Installation
```cmd
flutter doctor
```

Expected output: All checks should pass (iOS can be ignored on Windows)

### 2. Extract Project
```cmd
# Extract coachled_fitness_app.zip to C:\projects\
# Navigate to project
cd C:\projects\coachled_fitness_app
```

### 3. Install Dependencies
```cmd
flutter pub get
```

### 4. Firebase Setup (CRITICAL)

#### Option A: Automatic (Recommended)
```cmd
# Install FlutterFire CLI
dart pub global activate flutterfire_cli

# Add to PATH if needed
# C:\Users\YourName\AppData\Local\Pub\Cache\bin

# Run configuration
flutterfire configure
```

Follow prompts:
- Select or create Firebase project
- Select Android (and iOS if on Mac)
- This auto-generates firebase_options.dart

#### Option B: Manual Setup

1. Go to https://console.firebase.google.com
2. Create project: "coachled-fitness-app"
3. Add Android app:
   - Package name: com.coachled.fitness
   - Download google-services.json
   - Place in: android\app\google-services.json

4. Edit lib\firebase_options.dart:
   - Replace YOUR_PROJECT_ID with actual project ID
   - Replace YOUR_API_KEY with actual API key
   - Get these from Firebase Console > Project Settings

### 5. Enable Firebase Services

**In Firebase Console:**

1. **Authentication**
   - Click "Get Started"
   - Enable "Phone" provider
   - Add test number: +1 555 000 0001, code: 123456

2. **Firestore Database**
   - Click "Create database"
   - Production mode
   - Location: us-central1
   - Go to Rules tab
   - Copy/paste from firestore.rules file
   - Publish

3. **Storage**
   - Click "Get started"
   - Production mode
   - Go to Rules tab
   - Copy/paste from storage.rules file
   - Publish

### 6. Add Seed Data

**Firestore Console:**

1. Create collection: `injury_mappings`
2. Add 8 documents (one for each injury type):

**Document: knee**
```
injury_type: "knee"
hidden_exercise_ids: ["lunges", "deep_squats", "jump_squats"]
recommended_exercise_ids: ["leg_press", "step_ups", "glute_bridges"]
```

**Document: lower_back**
```
injury_type: "lower back"
hidden_exercise_ids: ["deadlifts", "good_mornings", "heavy_squats"]
recommended_exercise_ids: ["bird_dogs", "planks", "glute_bridges"]
```

**Document: shoulder**
```
injury_type: "shoulder"
hidden_exercise_ids: ["overhead_press", "pull_ups", "dips"]
recommended_exercise_ids: ["lateral_raises", "face_pulls", "band_pulls"]
```

(Add remaining 5 from firestore_seed_data.json)

3. Create collection: `exercises`
4. Add document: `goblet_squat_001`
```
exercise_id: "goblet_squat_001"
name: "Goblet Squat"
category: "Lower Body"
equipment: "Kettlebell"
video_url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
setup_cue: "Hold weight at chest, feet shoulder-width apart"
execution_cue: "Squat down keeping chest up, drive through heels"
common_mistake: "Knees caving inward, leaning forward"
regression: "Bodyweight squat"
progression: "Add weight"
```

### 7. Start Emulator

**Option A: Android Studio**
- Open Android Studio
- Tools > Device Manager
- Create or start virtual device
- Recommended: Pixel 5 with Android 13

**Option B: Command Line**
```cmd
# List available emulators
flutter emulators

# Launch emulator
flutter emulators --launch <emulator_id>
```

### 8. Run App
```cmd
flutter run
```

## Testing the App

### Login Flow
1. Phone: +1 555 000 0001
2. Code: 123456
3. Complete onboarding
4. Should see client home

### Create Test Program (For Workout Testing)

Firestore Console > programs collection > Add document:
```
program_id: "prog_001"
client_id: "[YOUR_USER_ID_FROM_USERS_COLLECTION]"
goal: "Build strength"
phase: "Foundation"
exercise_ids: ["goblet_squat_001"]
coach_message: "Welcome! Focus on form."
```

## Common Windows Issues

### Issue: Flutter not recognized
```cmd
# Add to PATH
setx PATH "%PATH%;C:\src\flutter\bin"
# Restart terminal
```

### Issue: Android licenses not accepted
```cmd
flutter doctor --android-licenses
# Accept all licenses
```

### Issue: Gradle build failed
```cmd
cd android
gradlew clean
cd ..
flutter clean
flutter pub get
flutter run
```

### Issue: Phone auth not working
- Verify phone auth enabled in Firebase
- Add SHA-1 fingerprint:
  ```cmd
  cd android
  gradlew signingReport
  # Copy SHA-1 to Firebase Console
  ```

### Issue: Emulator not starting
- Enable Hyper-V in Windows Features
- Or use physical Android device (USB debugging)

### Issue: Dependencies error
```cmd
flutter pub upgrade
flutter clean
flutter pub get
```

## Build APK for Testing

```cmd
flutter build apk --release
```

Output: build\app\outputs\flutter-apk\app-release.apk

Install on device:
```cmd
flutter install
```

## Project Structure

```
coachled_fitness_app\
├── lib\
│   ├── main.dart                   # App entry
│   ├── firebase_options.dart       # Firebase config
│   ├── models\                     # Data models (6 files)
│   ├── services\                   # Business logic (6 files)
│   ├── screens\                    # UI screens (9 files)
│   ├── providers\                  # State management
│   └── utils\                      # Helpers
├── android\                        # Android config
│   └── app\
│       ├── build.gradle            # Build config
│       └── google-services.json    # Firebase (you add)
├── firestore.rules                 # Database rules
├── storage.rules                   # Storage rules
├── pubspec.yaml                    # Dependencies
└── README.md                       # Documentation
```

## Next Steps

1. ✅ Complete Firebase setup
2. ✅ Add seed data
3. ✅ Run app and test login
4. ✅ Create test program
5. ✅ Test workout flow
6. Add more exercises
7. Invite test users
8. Deploy to Play Store

## Support

- Flutter Docs: https://docs.flutter.dev
- Firebase Docs: https://firebase.google.com/docs
- Issues: Check TROUBLESHOOTING.md

## Success Checklist

- [ ] flutter doctor shows all green
- [ ] flutter pub get succeeds
- [ ] Firebase configured (flutterfire configure)
- [ ] Phone auth enabled
- [ ] Firestore rules deployed
- [ ] Storage rules deployed
- [ ] Seed data added (injury_mappings + exercise)
- [ ] Emulator running
- [ ] flutter run succeeds
- [ ] Can login with test phone
- [ ] Onboarding works
- [ ] Client home displays

If all checked, your app is ready! 🎉
